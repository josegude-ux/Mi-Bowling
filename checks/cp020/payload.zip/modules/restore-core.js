/* CP020 - Validación y recuperación transaccional por compensación. Sin red. */
(function(root){'use strict';
const PREFIX='mi-bowling-', MAIN=PREFIX+'analitica-v2', LEGACY=PREFIX+'v1';
const MARK='bowling-restore-cp020-pending', LIMIT=96*1024*1024;
const own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
const object=o=>o!==null&&typeof o==='object'&&!Array.isArray(o);
const fail=m=>{throw Error(m)};
const check=(v,m)=>{if(!v)fail(m)};
const id=v=>typeof v==='string'&&/^[A-Za-z0-9_.:-]{1,160}$/.test(v)&&!['__proto__','constructor','prototype'].includes(v);
const safeKey=k=>typeof k==='string'&&/^mi-bowling-[A-Za-z0-9_.:-]{1,180}$/.test(k);
const text=(v)=>typeof v==='string';
const bytesTo64=b=>{let s='';for(let i=0;i<b.length;i+=8192)s+=String.fromCharCode(...b.subarray(i,i+8192));return btoa(s)};
const from64=s=>{check(text(s)&&s.length%4===0&&/^[A-Za-z0-9+/]*={0,2}$/.test(s),'Base64 PDF inválido');const b=Uint8Array.from(atob(s),c=>c.charCodeAt(0));check(bytesTo64(b)===s,'Base64 PDF no canónico');return b};
const digest=async b=>Array.from(new Uint8Array(await root.crypto.subtle.digest('SHA-256',b)),v=>v.toString(16).padStart(2,'0')).join('');
const stable=o=>JSON.stringify(Object.keys(o).sort().map(k=>[k,o[k]]));
// Compare persisted PDF fields, not JSON property insertion order (e.g. recovered journals).
const stablePDFs=pdfs=>JSON.stringify([...pdfs].sort((x,y)=>x.id.localeCompare(y.id)).map(p=>[p.id,p.type,p.bytes,p.sha256,p.base64]));
const sameState=(a,b)=>stable(a.storage)===stable(b.storage)&&stablePDFs(a.pdfs)===stablePDFs(b.pdfs);
function safeTree(o,depth=0){check(depth<=40,'Estructura demasiado profunda');if(o===null||typeof o!=='object')return;for(const k of Object.keys(o)){check(!['__proto__','prototype','constructor'].includes(k),'Clave interna no permitida');safeTree(o[k],depth+1)}}
function parse(s,label){try{const v=JSON.parse(s);safeTree(v);return v}catch(e){fail(label+': JSON no válido o estructura no admitida')}}
function unique(list,label){const seen=new Set();for(const v of list){check(object(v)&&id(v.id)&&!seen.has(v.id),label+': ID inválido o duplicado');seen.add(v.id)}return seen}
function fieldStrings(o,fields,label){for(const k of fields)if(own(o,k)&&o[k]!==null)check(text(o[k]),label+': '+k+' inválido')}
function validateDB(db){
 check(object(db)&&db.version===2&&Array.isArray(db.sessions)&&Array.isArray(db.balls)&&Array.isArray(db.patterns),'Se requiere una copia completa de MI BOWLING v2');
 check(db.hand==='diestro'||db.hand==='zurdo','Mano de lanzamiento inválida');
 unique(db.sessions,'Sesiones');unique(db.balls,'Bolas');unique(db.patterns,'Patrones');
 for(const b of db.balls){fieldStrings(b,['name','brand','photo'],'Bola');if(b.photo)check(/^data:image\/(?:png|jpeg|jpg|webp);base64,[A-Za-z0-9+/]+={0,2}$/i.test(b.photo),'Fotografía personal no admitida');}
 for(const p of db.patterns)fieldStrings(p,['name','pdfName','notes','maker','length','ratio','volume'],'Patrón');
 const games=new Set();let total=0;
 for(const s of db.sessions){check(s.type==='oficial'||s.type==='entrenamiento','Tipo de sesión inválido');check(Array.isArray(s.games),'Sesión sin lista de partidas');fieldStrings(s,['date','title','venue','notes','pattern','patternId','patternNotes','competition','currentBallId','leaguePlayer'],'Sesión');unique(s.games,'Partidas');
  for(const g of s.games){check(!games.has(g.id),'ID de partida repetido entre sesiones');games.add(g.id);total++;check(Array.isArray(g.rolls)&&g.rolls.length<=21,'Lanzamientos inválidos');if(g.pair!==undefined&&g.pair!==null)check(Array.isArray(g.pair)&&g.pair.length===2&&g.pair.every(Number.isInteger),'Pareja de pistas inválida');if(g.segments!==undefined)check(Array.isArray(g.segments)&&g.segments.every(e=>object(e)&&Number.isInteger(e.fromFrame)&&Array.isArray(e.pair)&&e.pair.length===2&&e.pair.every(Number.isInteger)),'Segmentos inválidos');
   const shots=new Set();for(const r of g.rolls){check(object(r)&&Number.isInteger(r.frame)&&r.frame>=1&&r.frame<=10&&Number.isInteger(r.ball)&&r.ball>=1&&r.ball<=(r.frame===10?3:2)&&Array.isArray(r.pins)&&r.pins.every(p=>Number.isInteger(p)&&p>=1&&p<=10)&&new Set(r.pins).size===r.pins.length,'Lanzamiento o bolos inválidos');check(!shots.has(r.frame+':'+r.ball),'Lanzamiento duplicado');shots.add(r.frame+':'+r.ball);if(r.ballId)check(id(r.ballId),'Referencia a bola inválida');}
  }
 }
 return {sessions:db.sessions.length,games:total,balls:db.balls.length,patterns:db.patterns.length,expected:db.patterns.filter(p=>p.pdfName).map(p=>p.id)};
}
function validateAux(storage){
 const j=k=>own(storage,k)?parse(storage[k],k):null;
 const select=j(PREFIX+'ball-selection-v1');if(select!==null)check(object(select)&&Object.values(select).every(a=>Array.isArray(a)&&a.every(id)),'Selecciones no válidas');
 const roster=j(PREFIX+'liga-rosters-v33');if(roster!==null)check(object(roster)&&Object.values(roster).every(a=>Array.isArray(a)&&a.every(text)),'Plantillas Liga no válidas');
 for(const k of [PREFIX+'liga-v1',PREFIX+'liga-acta-v32']){const v=j(k);if(v===null)continue;check(object(v)&&Array.isArray(v.matches),'Liga: actas no válidas');for(const m of v.matches){check(object(m)&&id(m.id)&&Array.isArray(m.players)&&m.players.length===12&&m.players.every(p=>object(p)&&text(p.name)&&['own','rival'].includes(p.team)&&[1,2].includes(p.trio)),'Liga: enfrentamiento no válido');for(const p of m.players){if(p.scores!==undefined)check(Array.isArray(p.scores)&&p.scores.length===2&&p.scores.every(x=>x===null||x===''||((text(x)||Number.isInteger(x))&&/^\d{1,3}$/.test(String(x))&&Number(x)<=300)),'Liga: puntuación inválida');if(p.names!==undefined)check(Array.isArray(p.names)&&p.names.every(text),'Liga: nombres inválidos');if(p.links!==undefined)check(object(p.links)&&Object.values(p.links).every(x=>object(x)&&id(x.sessionId)&&id(x.gameId)),'Liga: vínculos inválidos');}}}
 if(own(storage,PREFIX+'quick-layout'))check(['standard','compact','large'].includes(storage[PREFIX+'quick-layout']),'Disposición de registro inválida');
 if(own(storage,LEGACY))check(object(j(LEGACY)),'Copia histórica inválida');
}
async function validate(input){
 check(text(input)&&input.length<=LIMIT,'Archivo demasiado grande (máximo 96 MiB de texto)');const obj=parse(input,'Copia');
 check(object(obj)&&obj.format==='MI-BOWLING-BACKUP-COMPLETO'&&obj.version===1&&object(obj.storage)&&Array.isArray(obj.pdfs),'Formato de copia completa no reconocido');
 check(Object.keys(obj.storage).every(k=>safeKey(k)&&text(obj.storage[k]))&&own(obj.storage,MAIN),'Claves de almacenamiento inválidas o falta la base v2');
 const summary=validateDB(parse(obj.storage[MAIN],'Base de partidas'));validateAux(obj.storage);
 const pdfs=[],ids=new Set();for(const p of obj.pdfs){check(object(p)&&id(p.id)&&!ids.has(p.id)&&text(p.type)&&p.type===p.type.toLowerCase()&&/^[\x20-\x7e]*$/.test(p.type)&&Number.isInteger(p.bytes)&&p.bytes>=5&&p.bytes<=20*1024*1024&&text(p.sha256)&&/^[a-f0-9]{64}$/.test(p.sha256),'Registro PDF inválido o duplicado');const b=from64(p.base64);check(b.length===p.bytes&&String.fromCharCode(...b.subarray(0,5))==='%PDF-'&&await digest(b)===p.sha256,'PDF corrupto: '+p.id);ids.add(p.id);pdfs.push({id:p.id,type:p.type,bytes:p.bytes,sha256:p.sha256,base64:p.base64})}
 for(const k of summary.expected)check(ids.has(k),'Falta el PDF adjunto: '+k);
 return {state:{storage:{...obj.storage},pdfs},summary:{...summary,pdfs:pdfs.length,keys:Object.keys(obj.storage).length,exportedAt:text(obj.exportedAt)?obj.exportedAt:'',origin:text(obj.origin)?obj.origin:''}};
}
async function journalHash(state){return digest(new TextEncoder().encode(JSON.stringify({storage:JSON.parse(JSON.stringify(state.storage)),pdfs:state.pdfs})))}
async function verifiedJournal(adapter,token){const j=await adapter.readJournal();check(j&&j.token===token&&j.previous&&await journalHash(j.previous)===j.hash,'Registro de recuperación ausente o alterado; no escribir');return j}
async function recover(adapter){const token=adapter.marker();if(!token)return false;const j=await verifiedJournal(adapter,token);await adapter.apply(j.previous);check(sameState(await adapter.capture(),j.previous),'No se ha podido verificar la recuperación anterior');adapter.clearMarker();return true}
async function restore(adapter,target){
 check(!adapter.marker(),'Hay una recuperación pendiente');const previous=await adapter.capture();
 const token=root.crypto.randomUUID();const j={token,previous,hash:await journalHash(previous)};await adapter.writeJournal(j);await verifiedJournal(adapter,token);
 check(sameState(await adapter.capture(),previous),'Los datos cambiaron durante la preparación; no se ha restaurado');
 adapter.setMarker(token);check(adapter.marker()===token,'No se pudo registrar la recuperación; no se ha restaurado');
 try{await adapter.apply(target);check(sameState(await adapter.capture(),target),'Comprobación posterior incorrecta');adapter.clearMarker();return {ok:true,token}}
 catch(e){try{await recover(adapter);return {ok:false,recovered:true,error:String(e.message||e)}}catch(r){return {ok:false,recovered:false,error:String(e.message||e),recoveryError:String(r.message||r)}}}
}
const api={PREFIX,MARK,LIMIT,MAIN,validate,restore,recover,sameState,digest,bytesTo64,from64,verifiedJournal,journalHash};
if(typeof module==='object'&&module.exports)module.exports=api;else root.MiBowlingRestoreCore=Object.freeze(api);
})(globalThis);
