/* CP020 - Carga el motor exacto solo después del control de recuperación. */
(function(){'use strict';const mode=document.currentScript.dataset.mode;
const paths=['official-calendar-2026-2027.js?v=338fgb1','arsenal-insights.js?v=arsenal-catalog-cp035','official-ball-catalog.js?v=official-catalog-cp037','arsenal-view-lab.js?v=arsenal-catalog-cp037','app-tipo-3311-cp003.js','releases/backup-cp018-3311/backup-completo.js','releases/backup-cp018-3311/backup-ui.js','design-lab.js?v=20261109-lab1'];
const load=src=>new Promise((resolve,reject)=>{const s=document.createElement('script');s.src=src;s.async=false;s.onload=resolve;s.onerror=()=>reject(Error('No se pudo cargar '+src));document.body.append(s)});
const controls=[...document.querySelectorAll('.topbar,.design-lab-sidebar,#bottom-nav')];controls.forEach(e=>e.inert=true);const app=document.getElementById('app');app.textContent='Comprobando protección de datos…';
MiBowlingRestore.start(async()=>{for(const src of paths)await load(src);MiBowlingRestore.installUI();controls.forEach(e=>e.inert=false);
 // If async boot finished after load, CP004's load listener will not fire; register exactly the same worker here.
 if(document.readyState==='complete'&&'serviceWorker'in navigator&&location.protocol.startsWith('http')){try{swRegistration=await navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'});await swRegistration.update()}catch(e){}}
},mode);
})();
