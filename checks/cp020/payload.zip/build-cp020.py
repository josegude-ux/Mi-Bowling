#!/usr/bin/env python3
"""Build CP020 from exact CP004 and CP018. Never writes the repository or production."""
import argparse, hashlib, json, re, shutil, zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--modules',type=Path,default=Path(__file__).parent/'delta'/'releases'/'restore-cp020-3311');p.add_argument('--source-manifest',type=Path,required=True);a=p.parse_args()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
base=a.base;out=a.output
expected=json.loads(a.source_manifest.read_text());assert len(expected)==84
actual={str(f.relative_to(base)):sha(f) for f in base.rglob('*') if f.is_file()};assert actual==expected,'CP018 source must match exact 84 files'
assert sha(base/'index.html')=='497076dc1a70f000e75455d40f4e85430c598162a114b5d3dc2e6805c15c39dc'
assert sha(base/'sw.js')=='78c37d6cc5364336111cdb58b08c91a5b3ffa6d94f79bd52630da8c7034b4dfa'
assert sha(base/'app-tipo-3311-cp003.js')=='449484ec253923fc9b4f95d75cae7853218bb033df0aebb9358502780711775d'
assert not out.exists();out.mkdir(parents=True)
shell=(base/'index.html').read_text();start=' <script src="official-calendar-2026-2027.js?v=338fgb1"></script>';end=' <script src="design-lab.js?v=20261109-lab1"></script>'
assert shell.count(start)==1 and shell.count(end)==1
s=shell.index(start);e=shell.index(end)+len(end);assert e>s
paths=['restore-core.js','restore-runtime.js','restore-boot.js'];root='releases/restore-cp020-3311/'
message="""\n// CP020: confirm active release and reject other windows before replacing local data.\nself.addEventListener('message',event=>{if(event.data?.type!=='CP020_RESTORE_READY'||!event.ports?.[0])return;event.waitUntil((async()=>{const windows=await self.clients.matchAll({type:'window',includeUncontrolled:true});const other=windows.filter(c=>c.id!==event.source?.id&&c.url.startsWith(self.registration.scope)).length;event.ports[0].postMessage({release:RELEASE,other});})());});\n"""
old=(base/'sw.js').read_text();pat=re.search(r'const HASHES=(\{.*\});',old);H=json.loads(pat.group(1));assert len(H)==35
for mode,release in [('candidate','restore-cp020-3311'),('rollback','rollback-restore-cp020-3311')]:
 d=out/mode;shutil.copytree(base,d);shutil.copytree(a.modules,d/root)
 insert='\n'.join(' <script src="'+root+n+'"'+(' data-mode="'+mode+'"' if n=='restore-boot.js' else '')+'></script>' for n in paths)
 (d/'index.html').write_text(shell[:s]+insert+shell[e:]);h=dict(H);h['./']=h['./index.html']=sha(d/'index.html')
 for n in paths:h['./'+root+n]=sha(d/root/n)
 sw=old.replace('const RELEASE="backup-cp018-3311";','const RELEASE="'+release+'";').replace(pat.group(1),json.dumps(h,separators=(',',':')))+message
 (d/'sw.js').write_text(sw)
 for k,v in h.items():assert sha(d/(k[2:].split('?')[0] or 'index.html'))==v,k
 files={str(f.relative_to(d)):sha(f) for f in d.rglob('*') if f.is_file()};assert len(files)==87
 assert {k for k,v in expected.items() if files[k]!=v}=={'index.html','sw.js'}
 assert set(files)-set(expected)=={root+n for n in paths}
 (out/(mode+'-manifest.json')).write_text(json.dumps({'release':release,'cache':h,'files':files},indent=2))
 print('CP020 EXACT',mode,len(files),'files',len(h),'cache keys',flush=True)
