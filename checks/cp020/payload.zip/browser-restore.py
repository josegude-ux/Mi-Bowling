"""CP020 only: browser UI/IDB/cache, rollback, synthetic faults. Existing standard runners."""
import os,sys,json,time,hashlib,base64,threading,mimetypes
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlsplit
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
root=Path(os.environ['RUNNER_TEMP'])/'cp020-check';stage={'dir':root/'candidate'};engine=sys.argv[1]
class H(BaseHTTPRequestHandler):
 def do_GET(self):
  p=urlsplit(self.path).path
  if not p.startswith('/Mi-Bowling/'):self.send_error(404);return
  f=stage['dir']/(p[len('/Mi-Bowling/'):] or 'index.html')
  if not f.resolve().is_relative_to(stage['dir'].resolve()) or not f.is_file():self.send_error(404);return
  b=f.read_bytes();self.send_response(200);self.send_header('Content-Type',mimetypes.guess_type(f.name)[0] or 'application/octet-stream');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
 def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),H);threading.Thread(target=server.serve_forever,daemon=True).start();origin=f'http://127.0.0.1:{server.server_port}/Mi-Bowling/'
if engine=='safari-native':driver=webdriver.Safari()
else:
 o=webdriver.ChromeOptions();o.add_argument('--headless=new');o.add_argument('--no-sandbox');o.add_argument('--disable-dev-shm-usage');o.add_argument('--window-size=390,844');driver=webdriver.Chrome(options=o)
driver.set_page_load_timeout(30);driver.set_script_timeout(30)
def log(k,v=True):print('CP020',engine,k,json.dumps(v,ensure_ascii=False,default=str),flush=True)
def js(s,*a):return driver.execute_script(s,*a)
def aj(s,*a):
 v=driver.execute_async_script("const done=arguments[arguments.length-1];const args=Array.from(arguments).slice(0,-1);Promise.resolve().then(()=> ("+s+")(...args)).then(done,e=>done({error:String(e),stack:e.stack}))",*a)
 if isinstance(v,dict) and 'error' in v:raise AssertionError(v)
 return v
def wait_js(s):return WebDriverWait(driver,35).until(lambda _:js(s))
def wait_async(s):return WebDriverWait(driver,35).until(lambda _:aj(s))
def diagnostics():
 try:log('DIAGNOSTIC',aj("async()=>({gate:document.querySelector('[role=alertdialog]')?.innerText||'',marker:localStorage.getItem('bowling-restore-cp020-pending'),engine:typeof APP_VERSION,boot:document.querySelector('#app')?.innerText?.slice(0,200),locks:await navigator.locks.query()})"))
 except Exception as e:log('DIAGNOSTIC_ERROR',str(e))
def loaded():
 try:return wait_js("return typeof MiBowlingBackup==='object'&&typeof APP_VERSION!=='undefined'&&typeof liga32!=='undefined'&&document.querySelector('#app h2')!==null&&!document.querySelector('.topbar').inert&&!document.querySelector('[role=alertdialog]')")
 except Exception:diagnostics();raise
def snap():return js("return Object.fromEntries(Object.keys(localStorage).filter(k=>k.startsWith('mi-bowling-')).sort().map(k=>[k,localStorage.getItem(k)]))")
def current():return aj("async()=>{const x=await MiBowlingBackup.snapshot();return {storage:x.storage,pdfs:x.pdfs.sort((a,b)=>a.id.localeCompare(b.id))}}")
def pdf(id):return aj("async id=>{const b=await oilGet(id);return b?await b.text():null}",id)
def cache(stage):
 m=json.loads((root/(stage+'-manifest.json')).read_text());r=aj("""async m=>{const reg=await navigator.serviceWorker.getRegistration(),key='mi-bowling-release-'+m.release+'-'+encodeURIComponent(reg.scope);if(!(await caches.keys()).includes(key))throw Error('missing cache '+key);const c=await caches.open(key);for(const [p,h] of Object.entries(m.cache)){const r=await c.match(new URL(p,reg.scope).href);if(!r)throw Error('missing '+p);const hex=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await r.arrayBuffer())),v=>v.toString(16).padStart(2,'0')).join('');if(hex!==h)throw Error('hash '+p)}return {count:(await c.keys()).length,names:await caches.keys()}}""",m);assert r['count']==38;log('CACHE_'+stage,r);return r
def screen():return js("return document.querySelector('[role=alertdialog]')?.innerText||''")
def restore_input(obj,confirm=True):
 # Exercise the real input/change handler and file decoding, without automating the OS file picker.
 # Record confirmations/alerts; file dialog and native Safari/iPhone download are not certified.
 js("""const obj=arguments[0],accept=arguments[1];window._restoreAlerts=[];window._restoreConfirms=[];window.alert=m=>_restoreAlerts.push(String(m));window.confirm=m=>{_restoreConfirms.push(String(m));return accept};go('ajustes');const old=HTMLInputElement.prototype.click;HTMLInputElement.prototype.click=function(){if(this.type!=='file')return old.call(this)};try{const b=Array.from(document.querySelectorAll('#app button')).find(x=>x.textContent.includes('Restaurar copia completa'));if(!b)throw Error('Restore button absent');b.click()}finally{HTMLInputElement.prototype.click=old}const f=Array.from(document.querySelectorAll('input[type=file]')).find(e=>e.id!=='restore-file'&&e.hidden);if(!f)throw Error('file input absent');const dt=new DataTransfer();dt.items.add(new File([JSON.stringify(obj)],'ficticio.json',{type:'application/json'}));f.files=dt.files;f.dispatchEvent(new Event('change'));""",obj,confirm)
def alert_text():return js("return (window._restoreAlerts||[]).join(' ')")
def await_alert():return WebDriverWait(driver,35).until(lambda _:alert_text())
def await_panel(fragment):return WebDriverWait(driver,35).until(lambda _:fragment in screen())
def open_app():
 js("window._cp020ReloadToken='old-document';const b=Array.from(document.querySelectorAll('[role=alertdialog] button')).find(x=>x.textContent==='Abrir MI BOWLING');if(!b)throw Error('Open control absent');b.click()")
 wait_js("return !window._cp020ReloadToken&&typeof MiBowlingBackup==='object'&&typeof liga32!=='undefined'&&!document.querySelector('.topbar').inert&&!document.querySelector('[role=alertdialog]')");loaded()
def mark_interruption(state,token='F-CRASH',bad=False):
 return aj("""async ({state,token,bad})=>{const C=MiBowlingRestoreCore;state.pdfs=state.pdfs.map(p=>({base64:p.base64,sha256:p.sha256,bytes:p.bytes,type:p.type,id:p.id}));const j={token,previous:state,hash:bad?'bad':await C.journalHash(state)};await new Promise((res,rej)=>{const r=indexedDB.open('mi-bowling-restore-journal-v1',1);r.onupgradeneeded=()=>r.result.createObjectStore('journal');r.onerror=()=>rej(r.error);r.onsuccess=()=>{const d=r.result,t=d.transaction('journal','readwrite');t.objectStore('journal').put(j,'last');t.oncomplete=()=>{d.close();res()};t.onabort=()=>rej(t.error)}});localStorage.setItem(C.MARK,token);localStorage.setItem(C.MAIN,'{"version":2,"hand":"diestro","balls":[],"patterns":[],"sessions":[]}');await oilPut('F-CRASH-PDF',new Blob(['%PDF-1.4\\n% interrupted'],{type:'application/pdf'}));return true}""",{'state':state,'token':token,'bad':bad})
try:
 driver.get(origin);loaded();log('CAPABILITIES',driver.capabilities.get('browserVersion'));assert js('return isSecureContext&&!!navigator.locks?.request')
 wait_async("async()=>{const r=await navigator.serviceWorker.getRegistration();return r?.active?.state==='activated'}");driver.refresh();loaded();wait_js('return !!navigator.serviceWorker.controller');a=cache('candidate')
 # Genuine CP004 engine fixture. Exactly one completed perfect game, one pending session, one personal photo, real PDF store.
 assert aj("""async()=>{const pins=[1,2,3,4,5,6,7,8,9,10],rolls=Array.from({length:12},(_,i)=>({frame:Math.min(i+1,10),ball:i<10?1:i-8,pins,ballId:'F-B1'}));const common={date:'2026-11-01',venue:'Pista ficticia',patternId:'F-P1',pattern:'Patrón ficticio',currentBallId:'F-B1'};db=migrate({version:2,hand:'zurdo',balls:[{id:'F-B1',name:'Bola ficticia',brand:'Ficticia',photo:'data:image/png;base64,RklDVElDSU8='}],patterns:[{id:'F-P1',name:'Patrón ficticio',pdfName:'ficticio.pdf'}],sessions:[{...common,id:'F-S1',type:'oficial',title:'Oficial ficticia',games:[{id:'F-G1',rolls}]},{...common,id:'F-S2',type:'entrenamiento',title:'Ficticia [Tipo pendiente]',notes:LT_PENDING_NOTE,games:[{id:'F-G2',rolls:[]}]}]});save();localStorage.setItem(BALL_SELECTION_KEY,JSON.stringify({'F-S1':['F-B1']}));localStorage.setItem(LIGA_KEY,JSON.stringify(ligaData));localStorage.setItem(LIGA32_KEY,JSON.stringify(liga32));localStorage.setItem(LIGA33_ROSTER_KEY,JSON.stringify(liga33Roster));localStorage.setItem('mi-bowling-quick-layout','compact');localStorage.setItem('mi-bowling-fixture-extra','target');localStorage.setItem('unrelated-fixture','keep');await oilPut('F-P1',new Blob(['%PDF-1.4\\n% target CP020\\n%%EOF\\n'],{type:'application/pdf'}));return true}""") is True
 target=aj('async()=>await MiBowlingBackup.snapshot()');assert (aj('async x=>(await MiBowlingRestoreCore.validate(JSON.stringify(x))).summary',target))['games']==2
 assert aj("""async()=>{db.hand='diestro';db.sessions[0].title='Estado anterior distinto';db.patterns.push({id:'F-P2',name:'PDF anterior',pdfName:'anterior.pdf'});save();localStorage.setItem('mi-bowling-extra-old','old only');await oilPut('F-P2',new Blob(['%PDF-1.4\\n% old CP020\\n%%EOF\\n'],{type:'application/pdf'}));return true}""")
 previous=current();assert len(previous['pdfs'])==2
 # Genuine IDB transaction abort induced at PDF put (after LocalStorage changed); restore previous exact.
 js("const old=IDBObjectStore.prototype.put;let armed=true;IDBObjectStore.prototype.put=function(...a){if(armed&&this.name==='pdf'){armed=false;IDBObjectStore.prototype.put=old;throw new Error('Fictitious PDF transaction abort')}return old.apply(this,a)}")
 restore_input(target);await_panel('Se ha recuperado y verificado el estado anterior');assert current()==previous;log('REAL_IDB_FAILURE_COMPENSATED');open_app();assert current()==previous
 restore_input(target);await_panel('Restauración verificada');assert current()=={'storage':target['storage'],'pdfs':target['pdfs']};assert js("return localStorage.getItem('unrelated-fixture')")=='keep';assert pdf('F-P2') is None
 j=aj("async()=>await new Promise((res,rej)=>{const r=indexedDB.open('mi-bowling-restore-journal-v1',1);r.onsuccess=()=>{const d=r.result,t=d.transaction('journal','readonly'),q=t.objectStore('journal').get('last');q.onsuccess=()=>{d.close();res(q.result)}};r.onerror=()=>rej(r.error)})");assert j['previous']==previous;log('USER_RESTORE_EXACT_AND_PREVIOUS_RETAINED',{'keys':len(target['storage']),'pdfs':len(target['pdfs'])});open_app()
 assert js("return db.sessions.map(s=>[s.id,classificationMode(s),s.games.map(g=>complete(g)?score(g):null)])")==[['F-S1','oficial',[300]],['F-S2','pendiente',[None]]];assert js("return db.hand")=='zurdo';assert current()=={'storage':target['storage'],'pdfs':target['pdfs']};log('ENGINE_AFTER_RELOAD_300_PENDING')
 stable=current();assert mark_interruption(stable);driver.refresh();loaded();wait_js('return !localStorage.getItem(MiBowlingRestoreCore.MARK)');assert current()==stable;log('BOOT_RECOVERY_BEFORE_ENGINE')
 # Protected rollback must still recover an interrupted operation before loading old UI.
 stage['dir']=root/'rollback';assert aj("async()=>{await (await navigator.serviceWorker.getRegistration()).update();return true}") is True;wait_async('async()=>!!(await navigator.serviceWorker.getRegistration()).waiting');assert mark_interruption(stable,'F-ROLLBACK');driver.get('about:blank');time.sleep(2);driver.get(origin);loaded();wait_js('return !localStorage.getItem(MiBowlingRestoreCore.MARK)');wait_js('return !!navigator.serviceWorker.controller');assert current()==stable;go=js("go('ajustes');return Array.from(document.querySelectorAll('#app button')).some(b=>b.textContent.includes('Restaurar copia completa'))");assert go is False;b=cache('rollback');assert set(a['names']).issubset(b['names']);log('PROTECTED_ROLLBACK_RECOVERS_AND_HIDES_RESTORE')
 # Fail closed on corrupted journal; no engine is loaded. Fictitious data only.
 assert mark_interruption(stable,'F-BAD',True);driver.refresh();await_panel('No se ha podido terminar la recuperación');assert js("return typeof APP_VERSION")=='undefined';assert js('return !!localStorage.getItem(MiBowlingRestoreCore.MARK)');log('CORRUPT_JOURNAL_BLOCKS_ENGINE')
 log('PASS')
except Exception:
 diagnostics();raise
finally:driver.quit();server.shutdown();server.server_close()
