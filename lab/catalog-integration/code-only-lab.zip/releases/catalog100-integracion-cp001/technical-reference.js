(function(root){'use strict';
 const bridge=root.MiBowlingCatalog100Bridge, entries=root.MiBowlingCatalog20?.entries||[];
 const map=new Map();for(const e of entries){const s=bridge?.SEED[e.rank-1];if(s&&s.brand===e.brand&&s.model===e.model)map.set(s.id,{s,e});}
 const get=x=>{const r=map.get(x?.id);return r&&r.s.brand===x.brand&&r.s.model===x.model&&r.s.approved===x.approved?r.e:null};
 function markup(x,esc){const e=get(x);if(!e||e.state!=='ficha-fabricante-verificada')return '<p class="hint">Ficha técnica pendiente de acreditar para esta referencia.</p>';
 const fields=[['Cubierta','cover'],['Núcleo','core'],['RG','rg'],['Diferencial','diff'],['Acabado','finish'],['Aceite indicado','oil']];return '<details class="catalog100-tech"><summary>Ficha técnica acreditada</summary><dl class="arsenal-facts">'+fields.filter(([_,k])=>e[k]).map(([label,k])=>'<div><dt>'+esc(label)+'</dt><dd>'+esc(e[k])+'</dd></div>').join('')+'</dl><p class="hint">'+esc(e.note||'')+' · Referencia comercial, no identifica tu unidad física.</p><a href="'+esc(e.technicalSource)+'" target="_blank" rel="noopener noreferrer">Fuente técnica primaria</a></details>'}
 root.MiBowlingCatalog100Technical=Object.freeze({get,markup});
})(window);
