from pathlib import Path
import argparse, tempfile, threading, json, hashlib
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
from playwright.sync_api import sync_playwright, expect
p=argparse.ArgumentParser();p.add_argument('engine',choices=['chromium','webkit']);a=p.parse_args();root=Path(__file__).resolve().parent
class Handler(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
srv=ThreadingHTTPServer(('127.0.0.1',0),partial(Handler,directory=str(root/'candidate')));threading.Thread(target=srv.serve_forever,daemon=True).start();url=f'http://127.0.0.1:{srv.server_port}/'
def game(id,kind,ball='A',include=True):
 r=[]
 for f in range(1,11):
  def add(b,p):r.append(dict(frame=f,ball=b,pins=list(p),ballId=ball,lane=7,pair=[7,8],foul=False))
  if kind=='strike':
   add(1,range(1,11))
   if f==10:add(2,range(1,11));add(3,range(1,11))
  elif kind=='spare':
   add(1,range(1,10));add(2,[10]);
   if f==10:add(3,range(1,10))
  elif kind=='incomplete':
   if f==1:add(1,range(1,11))
  else:add(1,range(1,9));add(2,[9])
 return dict(id=id,includeStats=include,rolls=r,pair=[7,8],startLane=7,segments=[])
def sess(id,date,games,**kw):return dict(id=id,date=date,type='entrenamiento',title='LAB '+id,venue='Bolera ficticia',games=games,**kw)
fixture=dict(version=2,hand='diestro',balls=[dict(id='A',brand='LAB',model='A'),dict(id='B',brand='LAB',model='B')],patterns=[dict(id='P',name='Patrón LAB',pdfName='lab.pdf')],sessions=[sess('S1','2026-11-01',[game('G1','strike'),game('G2','spare'),game('G3','strike'),game('G4','open'),game('G5','strike'),game('G6','strike')]),sess('S2','2026-11-02',[game('G7','strike','B'),game('G8','incomplete'),game('G9','strike','B'),game('G10','strike','A',False),game('G11','strike','B')]),dict(sess('PEND','2026-11-03',[game('GP','strike')]),title='LAB [Tipo pendiente]',notes='Tipo de jornada no confirmado en la copia de origen. Se muestra provisionalmente en Entrenamientos por compatibilidad y no se incluye en las estadísticas de entrenamiento hasta que se confirme su clasificación.'),dict(sess('OFF','2026-11-04',[game('GO','strike')]),type='oficial'),dict(sess('RIVAL','2026-11-05',[game('GR','strike')]),type='oficial',leagueOther=True)])
def snapshot(pg):return pg.evaluate('()=>Object.fromEntries(Object.keys(localStorage).sort().map(k=>[k,localStorage.getItem(k)]))')
def agg(pg):return pg.evaluate("()=>JSON.stringify(periodAggregate(aggregate(statMode,statsBallId)))")
def log(label,detail=None):print('STATS_LAB',a.engine,label,json.dumps(detail,ensure_ascii=False),flush=True)
with sync_playwright() as pw,tempfile.TemporaryDirectory(prefix='stats-lab-') as profile:
 engine=getattr(pw,a.engine);ctx=engine.launch_persistent_context(profile,headless=True,service_workers='block',viewport={'width':390,'height':844});pg=ctx.pages[0]
 try:
  pg.goto(url);expect(pg.locator('#app')).to_be_visible();pg.evaluate("async data=>{localStorage.setItem(KEY,JSON.stringify(migrate(data)));localStorage.setItem(BALL_SELECTION_KEY,JSON.stringify({S1:['A'],__next__:[]}));await oilPut('P',new File(['%PDF-1.4\\n% synthetic\\n%%EOF\\n'],'lab.pdf',{type:'application/pdf'}));}",fixture);pg.reload();expect(pg.locator('#app')).to_be_visible();pg.get_by_role('button',name='Estadísticas',exact=True).click();base=snapshot(pg);oldagg=agg(pg);log('BASE',pg.evaluate('({version:APP_VERSION,totals:aggregate(statMode).totals})'))
  assert pg.evaluate('APP_VERSION')=='3.3.11-estadisticas-LAB';assert pg.evaluate('aggregate(statMode).totals.length')==9
  pg.locator('[data-record="clean"]').click();results=pg.locator('#stats-record-results');expect(results).to_be_visible()
  for width in [320,360,390]:
   pg.set_viewport_size({'width':width,'height':844});measure=pg.evaluate("()=>({width:innerWidth,doc:document.documentElement.scrollWidth,rows:[...document.querySelectorAll('.stats-record-row,.stats-record-tile')].map(e=>({w:e.getBoundingClientRect().width,h:e.getBoundingClientRect().height,r:e.getBoundingClientRect().right,l:e.getBoundingClientRect().left}))})");assert measure['doc']<=width+1 and all(r['h']>=44 and r['l']>=0 and r['r']<=width+1 for r in measure['rows']),measure;log('RESPONSIVE',{'width':width,'rows':len(measure['rows'])});pg.screenshot(path=str(root/f'stats-{a.engine}-{width}.png'),full_page=True)
  assert snapshot(pg)==base and agg(pg)==oldagg
  pg.set_viewport_size({'width':320,'height':844})
  metrics=pg.evaluate("""()=>{const targets=[...document.querySelectorAll('.stats-record-link')];const links=targets.map(e=>({text:e.textContent,width:e.clientWidth,scroll:e.scrollWidth,whiteSpace:getComputedStyle(e).whiteSpace}));const label=document.querySelector('[data-record=streak] .label');const text=[...label.childNodes].find(n=>n.nodeType===3&&n.textContent.includes('consecutivos'));const offset=text.textContent.indexOf('consecutivos');const r=document.createRange();r.setStart(text,offset);r.setEnd(text,offset+'consecutivos'.length);return {links,wordRects:r.getClientRects().length,wordBreak:getComputedStyle(label).wordBreak,overflowWrap:getComputedStyle(label).overflowWrap}}""")
  assert metrics['wordRects']==1 and all(r['whiteSpace']=='nowrap' and r['scroll']<=r['width']+1 for r in metrics['links']),metrics;log('NO_SPLIT_WORDS_AND_LINKS',metrics);log('PASS')
 finally:ctx.close();srv.shutdown()
