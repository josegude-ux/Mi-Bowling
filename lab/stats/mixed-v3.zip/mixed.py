from pathlib import Path
import argparse, tempfile, threading, json, hashlib
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
from playwright.sync_api import sync_playwright, expect
p=argparse.ArgumentParser();p.add_argument('engine',choices=['chromium','webkit']);a=p.parse_args();root=Path(__file__).resolve().parent
class Handler(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
srv=ThreadingHTTPServer(('127.0.0.1',0),partial(Handler,directory=str(root/'candidate')));threading.Thread(target=srv.serve_forever,daemon=True).start();url=f'http://127.0.0.1:{srv.server_port}/'
def game(id,kind,ball='A',include=True):
 r=[]
 for f in range(1,11):
  def add(b,p):r.append(dict(frame=f,ball=b,pins=list(p),ballId=ball,lane=7,pair=[7,8],foul=False))
  if kind=='strike':
   add(1,range(1,11))
   if f==10:add(2,range(1,11));add(3,range(1,11))
  elif kind=='spare':
   add(1,range(1,10));add(2,[10]);
   if f==10:add(3,range(1,10))
  elif kind=='incomplete':
   if f==1:add(1,range(1,11))
  else:add(1,range(1,9));add(2,[9])
 return dict(id=id,includeStats=include,rolls=r,pair=[7,8],startLane=7,segments=[])
def sess(id,date,games,**kw):return dict(id=id,date=date,type='entrenamiento',title='LAB '+id,venue='Bolera ficticia',games=games,**kw)
fixture=dict(version=2,hand='diestro',balls=[dict(id='A',brand='LAB',model='A'),dict(id='B',brand='LAB',model='B')],patterns=[dict(id='P',name='Patrón LAB',pdfName='lab.pdf')],sessions=[sess('S1','2026-11-01',[game('G1','strike'),game('G2','spare'),game('G3','strike'),game('G4','open'),game('G5','strike'),game('G6','strike')]),sess('S2','2026-11-02',[game('G7','strike','B'),game('G8','incomplete'),game('G9','strike','B'),game('G10','strike','A',False),game('G11','strike','B')]),dict(sess('PEND','2026-11-03',[game('GP','strike')]),title='LAB [Tipo pendiente]',notes='Tipo de jornada no confirmado en la copia de origen. Se muestra provisionalmente en Entrenamientos por compatibilidad y no se incluye en las estadísticas de entrenamiento hasta que se confirme su clasificación.'),dict(sess('OFF','2026-11-04',[game('GO','strike')]),type='oficial'),dict(sess('RIVAL','2026-11-05',[game('GR','strike')]),type='oficial',leagueOther=True)])
def snapshot(pg):return pg.evaluate('()=>Object.fromEntries(Object.keys(localStorage).sort().map(k=>[k,localStorage.getItem(k)]))')
def agg(pg):return pg.evaluate("()=>JSON.stringify(periodAggregate(aggregate(statMode,statsBallId)))")
def log(label,detail=None):print('STATS_LAB',a.engine,label,json.dumps(detail,ensure_ascii=False),flush=True)
# Targeted regression: one mixed-ball perfect game, no historical suite rerun.
g=game('GM','strike');g['rolls']=[dict(r,ballId='A' if i<5 else 'B') for i,r in enumerate(g['rolls'])];fixture['sessions']=[sess('SM','2026-11-01',[g])]
with sync_playwright() as pw,tempfile.TemporaryDirectory(prefix='stats-mixed-') as profile:
 engine=getattr(pw,a.engine);ctx=engine.launch_persistent_context(profile,headless=True,service_workers='block',viewport={'width':390,'height':844});pg=ctx.pages[0]
 try:
  pg.goto(url);expect(pg.locator('#app')).to_be_visible();pg.evaluate("data=>localStorage.setItem(KEY,JSON.stringify(migrate(data)))",fixture);pg.reload();pg.get_by_role('button',name='Estadísticas',exact=True).click();before=snapshot(pg)
  for ball,n in [('',12),('A',5),('B',7)]:
   pg.locator('#stats-ball').select_option(ball);pg.locator('[data-record="streak"]').click();expect(pg.locator('[data-record="streak"] .value')).to_have_text(str(n));result=pg.locator('#stats-record-results [data-game="GM"]');expect(result).to_contain_text(f'{n} strikes seguidos');expect(result).to_contain_text('300 pts');result.click();expect(pg.locator('#stats-original-game')).to_contain_text('300 pts');expect(pg.locator('#stats-original-game tbody tr')).to_have_count(10);pg.get_by_role('button',name='Volver a récords').first.click();assert pg.locator('#stats-ball').input_value()==ball;assert snapshot(pg)==before;log('MIXED_BALL_STREAK',{'ball':ball,'streak':n,'score':300})
  log('PASS')
 finally:ctx.close();srv.shutdown()
