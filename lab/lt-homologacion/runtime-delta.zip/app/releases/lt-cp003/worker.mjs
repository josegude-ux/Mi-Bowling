import {inspect,preview} from './importer.mjs';
let source;
self.onmessage=async({data:m})=>{try{if(m.op==='inspect'){source=inspect(m.bytes);self.postMessage({op:'inspected',users:source.users,events:[...source.events.values()].map(e=>({id:e.eventID,name:e.eventName,date:e.dayYYYYMMDD}))})}else if(m.op==='preview'){self.postMessage({op:'previewed',plan:await preview(source,m.userId,m.target,m.types)})}}catch(e){self.postMessage({op:'error',message:e.message})}};
