#!/usr/bin/env python3
"""New real-browser acceptance cases; NOT EXECUTED at CP006.
Copy to tests/ in verified CP005 extraction. Only authorized isolated loopback.
--authorized documents approval; it does not create approval or bypass policy.
All data synthetic. Each scenario gets a fresh context. No production URLs.
"""
import argparse
import ast
import base64
import hashlib
import json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--authorized', action='store_true', required=True)
p.add_argument('--engine', choices=['chromium', 'webkit'], required=True)
p.add_argument('--scenario', choices=['aux-before', 'aux-after', 'terminal-edit', 'cancel-preview', 'quota'], required=True)
a = p.parse_args()
root = Path(__file__).resolve().parents[1]
origin = 'http://127.0.0.1:8767'
key = 'mi-bowling-analitica-v2'
aux = 'mi-bowling-ball-selection-v1'
# Reuse the exact previous interruption harness, without executing its top-level browser suite.
old = root/'tests/browser-cp004-authorized.py'
start = next(ast.literal_eval(n.value) for n in ast.parse(old.read_text()).body
             if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'START' for t in n.targets))
fixture = root/'evidence/fixture.sqlite'
pdf = root/'evidence/cp004/patron-ficticio.pdf'
manifest = {n.removeprefix('./'): h for h,n in (line.split('  ',1) for line in (root/'manifest.sha256').read_text().splitlines() if line)}
for path in (fixture, pdf, old, root/'app/releases/lt-cp003/transaction.mjs'):
    assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest[path.relative_to(root).as_posix()], path.name
fixture64 = base64.b64encode(fixture.read_bytes()).decode()
pdf64 = base64.b64encode(pdf.read_bytes()).decode()
from playwright.sync_api import sync_playwright, expect

def ready(page):
    expect(page.locator('#lt-app-shell')).to_be_visible(timeout=20000)
    assert page.evaluate('!!window.MiBowlingLTHost')

def storage(page):
    return page.evaluate("""()=>Object.fromEntries(Object.keys(localStorage).sort().map(k=>[k,localStorage.getItem(k)]))""")

def receipt(page):
    return page.evaluate('window.MiBowlingLTGate.journal.get()')

def seed(page):
    page.evaluate("""async pdf=>{const d={version:2,hand:'zurdo',balls:[{id:'LAB-CP006-B',brand:'Marca ficticia',model:'Bola ficticia',photo:''}],patterns:[{id:'LAB-CP006-PDF',name:'Patrón ficticio',pdfName:'patron-ficticio.pdf'}],sessions:[]};await oilPut('LAB-CP006-PDF',new Blob([Uint8Array.from(atob(pdf),c=>c.charCodeAt(0))],{type:'application/pdf'}));localStorage.setItem('mi-bowling-analitica-v2',JSON.stringify(d));localStorage.setItem('mi-bowling-ball-selection-v1',JSON.stringify({__next__:['LAB-CP006-B']}));}""", pdf64)
    page.reload(wait_until='commit'); ready(page)
    return page.evaluate('window.MiBowlingBackup.snapshot()')

def preview(page):
    page.evaluate("go('ajustes')")
    page.locator('#lt-open').click()
    page.locator('#lt-file').set_input_files(str(fixture))
    expect(page.locator('#lt-choice')).to_be_visible(timeout=20000)
    page.locator('#lt-user').select_option('1')
    page.locator('[data-event="1"]').select_option('oficial')
    page.locator('[data-event="2"]').select_option('entrenamiento')
    page.locator('#lt-preview').click()
    expect(page.locator('#lt-review')).to_be_visible(timeout=20000)

def confirm(page):
    page.locator('#lt-incomplete').check()
    page.locator('#lt-confirm').check()
    page.locator('#lt-apply').click()

with sync_playwright() as pw:
    browser = getattr(pw, a.engine).launch()
    print('ENGINE', a.engine, browser.version, 'SCENARIO', a.scenario, flush=True)
    ctx = browser.new_context(accept_downloads=True, viewport={'width':390,'height':844})
    external = []
    ctx.on('request', lambda r: external.append(r.url) if not r.url.startswith((origin+'/', 'blob:', 'data:')) else None)
    try:
        first = ctx.new_page(); first.goto(origin+'/', wait_until='commit'); ready(first)
        before = seed(first)
        if a.scenario.startswith('aux-'):
            phase = a.scenario.split('-')[1]
            first.evaluate(start, {'fixture':fixture64, 'phase':phase})
            first.wait_for_function("window.__cp004Phase==='barrier' || window.__cp004Phase?.startsWith('error:')", timeout=20000)
            assert first.evaluate('window.__cp004Phase') == 'barrier'
            pending = receipt(first); assert pending['status'] == 'prepared'
            expected_main = pending['oldRaw'] if phase == 'before' else pending['nextRaw']
            assert first.evaluate('(k)=>localStorage.getItem(k)', key) == expected_main
            other = ctx.new_page(); other.goto(origin+'/', wait_until='commit')
            expect(other.locator('#lt-gate-status')).to_contain_text('Otra ventana')
            assert not other.evaluate('!!window.MiBowlingLTHost')
            # Deliberate fault injection by test harness only, not a permitted app writer.
            other.evaluate('k=>localStorage.setItem(k, JSON.stringify({__next__:[]}))', aux)
            diverged = storage(other); assert diverged[aux] != before['storage'][aux]
            first.close(); other.reload(wait_until='commit')
            expect(other.locator('#lt-gate-status')).to_contain_text('Resultado divergente', timeout=20000)
            assert not other.evaluate('!!window.MiBowlingLTHost')
            assert storage(other) == diverged
            assert receipt(other) == pending
            with other.expect_download() as dl:
                other.get_by_role('button',name='Descargar copia completa anterior',exact=True).click()
            assert json.loads(Path(dl.value.path()).read_text()) == pending['backup']
        elif a.scenario == 'terminal-edit':
            preview(first); confirm(first)
            expect(first.locator('#lt-status')).to_contain_text('6 partidas añadidas',timeout=20000)
            first.locator('#lt-close').click(); terminal=receipt(first); assert terminal['status']=='applied'
            first.evaluate("go('ajustes')")
            first.locator('#mano-bowling').select_option('diestro')
            saved=storage(first); assert json.loads(saved[key])['hand']=='diestro'
            assert saved[key] != terminal['nextRaw']
            first.reload(wait_until='commit'); ready(first)
            assert storage(first)==saved and receipt(first)==terminal
            assert first.evaluate("aggregate('oficial').totals.join(',')")=='300,150,90'
            assert first.evaluate('window.MiBowlingBackup.snapshot()')['pdfs']==before['pdfs']
            first.evaluate("go('ajustes')")
            with first.expect_download() as dl:
                first.get_by_role('button',name='↓ Exportar copia',exact=True).click()
            exported=json.loads(Path(dl.value.path()).read_text()); assert exported['hand']=='diestro'
            assert exported['sessions']==json.loads(saved[key])['sessions']
        elif a.scenario == 'cancel-preview':
            preview(first); saved=storage(first); assert receipt(first) is None
            first.locator('#lt-close').click()
            expect(first.locator('#lt-dialog')).to_have_count(0)
            assert storage(first)==saved and receipt(first) is None
            assert first.evaluate('window.MiBowlingBackup.snapshot()')['pdfs']==before['pdfs']
            first.reload(wait_until='commit'); ready(first)
            assert storage(first)==saved and receipt(first) is None
        else:
            # Real browser quota, no mock of Storage. Filler key is test-only and
            # outside mi-bowling-* so it does not invalidate the captured snapshot.
            preview(first); saved=storage(first); assert receipt(first) is None
            found=first.evaluate("""()=>{const k='lab-cp006-quota-only',cap=8*1024*1024;let lo=0,hi=cap;const write=n=>{try{localStorage.setItem(k,'x'.repeat(n));return true}catch(e){if(e.name!=='QuotaExceededError')throw e;return false}};if(write(hi)){localStorage.removeItem(k);return false}while(hi-lo>1){const m=Math.floor((hi+lo)/2);if(write(m))lo=m;else hi=m}if(!write(lo))throw Error('quota changed');return true}""")
            if not found: raise RuntimeError('PENDING: no real quota reached within capped synthetic allocation')
            try:
                confirm(first)
                first.wait_for_function("""async()=>{const r=await window.MiBowlingLTGate.journal.get();return r?.status==='not-applied' && !document.querySelector('#lt-apply').disabled}""", timeout=20000)
                assert first.evaluate('(k)=>localStorage.getItem(k)',key)==saved[key]
                assert receipt(first)['status']=='not-applied'
            finally:
                first.evaluate("localStorage.removeItem('lab-cp006-quota-only')")
            assert storage(first)==saved
            first.locator('#lt-close').click(); first.reload(wait_until='commit'); ready(first)
            assert storage(first)==saved and receipt(first)['status']=='not-applied'
            assert first.evaluate('window.MiBowlingBackup.snapshot()')['pdfs']==before['pdfs']
        assert not external, external
        print('PASS',a.engine,a.scenario,flush=True)
    finally:
        ctx.close(); browser.close()
