#!/usr/bin/env python3
"""CP004 extension, NOT executed in the blocked environment.
Only execute with a new authorized browser/profile and the isolated loopback server.
Tests actual APIs with fictitious data; injected barriers model interruption, not physical power loss.
"""
import argparse, base64, hashlib, pathlib, json
p=argparse.ArgumentParser();p.add_argument('--authorized',action='store_true',required=True);p.add_argument('--engine',choices=['chromium','webkit'],required=True);a=p.parse_args()
from playwright.sync_api import sync_playwright, expect
root=pathlib.Path(__file__).resolve().parents[1];origin='http://127.0.0.1:8767';key='mi-bowling-analitica-v2';lock='mi-bowling-lt-cp003-origin-writer'
fixture=base64.b64encode((root/'evidence/fixture.sqlite').read_bytes()).decode();pdf=(root/'evidence/cp004/patron-ficticio.pdf').read_bytes();pdf64=base64.b64encode(pdf).decode()

def ready(page):
 expect(page.locator('#lt-app-shell')).to_be_visible(timeout=20000);assert page.evaluate('!!window.MiBowlingLTHost')

def new_page(ctx):
 page=ctx.new_page();page.goto(origin+'/',wait_until='commit');ready(page);return page

def seed(page):
 page.evaluate('''async pdf=>{const bytes=Uint8Array.from(atob(pdf),c=>c.charCodeAt(0));const d={version:2,hand:'zurdo',balls:[],patterns:[{id:'LAB-CP004-PDF',name:'Patrón ficticio CP004',pdfName:'patron-ficticio.pdf'}],sessions:[]};await oilPut('LAB-CP004-PDF',new Blob([bytes],{type:'application/pdf'}));localStorage.setItem('mi-bowling-analitica-v2',JSON.stringify(d));}''',pdf64)
 page.reload(wait_until='commit');ready(page)
 return page.evaluate('window.MiBowlingBackup.snapshot()')

START='''async ({fixture,phase})=>{const gate=window.MiBowlingLTGate,host=window.MiBowlingLTHost;gate.hold();const m=await import('/releases/lt-cp003/transaction.mjs'),i=await import('/releases/lt-cp003/importer.mjs');const base=host.capture(),src=i.inspect(Uint8Array.from(atob(fixture),c=>c.charCodeAt(0))),plan=await i.preview(src,1,base.canonical,{1:'oficial',2:'entrenamiento'}),candidate=m.candidateFrom(plan,base,{confirmed:true,includeIncomplete:true},host.migrate);window.__cp004Phase='starting';window.__cp004Expected=candidate.raw;const journal={get:()=>gate.journal.get(),async put(record){if(phase==='after'&&record.status==='applied'){window.__cp004Phase='barrier';await new Promise(()=>{});}await gate.journal.put(record);if(phase==='before'&&record.status==='prepared'){window.__cp004Phase='barrier';await new Promise(()=>{});}}};void m.commitIntegrated({storage:localStorage,journal,base,candidate,backup:window.MiBowlingBackup.snapshot,guard:gate.assertImport,install:host.install}).catch(e=>{window.__cp004Phase='error:'+e.message;});}'''

with sync_playwright() as pw:
 b=getattr(pw,a.engine).launch();print('Browser',a.engine,b.version)
 for phase in ['before','after']:
  ctx=b.new_context(accept_downloads=True,viewport={'width':390,'height':844});external=[]
  ctx.on('request',lambda r:external.append(r.url) if not r.url.startswith(origin+'/') and not r.url.startswith(('blob:','data:')) else None)
  first=new_page(ctx);snapshot=seed(first);first.evaluate(START,{'fixture':fixture,'phase':phase});first.wait_for_function("window.__cp004Phase==='barrier' || window.__cp004Phase?.startsWith('error:')",timeout=20000);assert first.evaluate('window.__cp004Phase')=='barrier';candidate=first.evaluate('window.__cp004Expected');assert first.evaluate('window.MiBowlingLTGate.journal.get()')['status']=='prepared'
  other=ctx.new_page();other.goto(origin+'/',wait_until='commit');expect(other.locator('#lt-gate-status')).to_contain_text('Otra ventana');assert not other.evaluate('!!window.MiBowlingLTHost')
  first.close();other.reload(wait_until='commit');ready(other);receipt=other.evaluate('window.MiBowlingLTGate.journal.get()');assert receipt['status']==('not-applied' if phase=='before' else 'applied');assert other.evaluate('(k)=>localStorage.getItem(k)',key)==(snapshot['storage'][key] if phase=='before' else candidate)
  final=other.evaluate('window.MiBowlingBackup.snapshot()');assert final['pdfs']==snapshot['pdfs'];assert all(v==final['storage'][k] for k,v in snapshot['storage'].items() if k!=key)
  # Real download through unchanged pattern UI; compare byte-for-byte, not just header.
  other.evaluate("selectedPatternId='LAB-CP004-PDF';go('patrones')")
  with other.expect_download() as dl:other.get_by_role('button',name='Descargar PDF',exact=True).click()
  assert pathlib.Path(dl.value.path()).read_bytes()==pdf
  if phase=='after':
   assert other.evaluate("aggregate('oficial').totals.join(',')")=='300,150,90'
   # Corrupt a fictitious durable terminal record; restart must fail closed without erasing LS.
   other.evaluate("async()=>{const j=window.MiBowlingLTGate.journal,r=await j.get();r.backup.pdfs[0].sha256='bad';await j.put(r)}")
   other.reload(wait_until='commit');expect(other.locator('#lt-gate-status')).to_contain_text('no verificable');assert not other.evaluate('!!window.MiBowlingLTHost');assert other.evaluate('(k)=>localStorage.getItem(k)',key)==candidate
   expect(other.get_by_role('button',name='Descargar registro NO verificado para revisión')).to_be_visible()
  assert not external,external;ctx.close();print('PASS real LS/IDB, close/reopen, second writer, PDF download',phase)
 # Observe actual BFCache eligibility, never force it or assume a restoration happened.
 ctx=b.new_context(viewport={'width':390,'height':844});ctx.add_init_script("window.__cp004PageShows=[];addEventListener('pageshow',e=>window.__cp004PageShows.push(e.persisted));");first=new_page(ctx);first.goto(origin+'/catalogo-bolas/',wait_until='commit');first.wait_for_function("document.querySelector('#lt-app-shell')?.hidden===false || document.querySelector('#lt-gate-status')?.textContent.includes('Otra ventana')")
 other=ctx.new_page();other.goto(origin+'/',wait_until='commit');other.wait_for_function("document.querySelector('#lt-app-shell')?.hidden===false || document.querySelector('#lt-gate-status')?.textContent.includes('Otra ventana')")
 first.evaluate('history.back()');first.wait_for_url(origin+'/');first.wait_for_function("document.querySelector('#lt-app-shell')?.hidden===false || document.querySelector('#lt-gate-status')?.textContent.includes('Otra ventana')")
 restored=first.evaluate('window.__cp004PageShows.includes(true)');active=[pg.locator('#lt-app-shell').is_visible() for pg in (first,other)];assert sum(active)<=1,active
 held=first.evaluate('(name)=>navigator.locks.query().then(x=>x.held.filter(h=>h.name===name).length)',lock);assert held<=1;print('BFCache observed=',restored,'active writers=',active,'held=',held)
 if not restored:print('PENDING actual BFCache restore: engine did not restore from cache')
 ctx.close();b.close()
