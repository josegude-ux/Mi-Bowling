#!/usr/bin/env python3
"""Pending real-browser tests. Execute only in a newly authorized, isolated environment.
No personal input, no remote requests, no use of production origin. Server must already run.
"""
import argparse, pathlib, json
p=argparse.ArgumentParser();p.add_argument('--authorized',action='store_true',required=True);p.add_argument('--engine',choices=['chromium','webkit'],required=True);a=p.parse_args()
from playwright.sync_api import sync_playwright, expect
root=pathlib.Path(__file__).resolve().parents[1];origin='http://127.0.0.1:8767';key='mi-bowling-analitica-v2'
with sync_playwright() as pw:
 b=getattr(pw,a.engine).launch();c=b.new_context(accept_downloads=True,viewport={'width':390,'height':844});page=c.new_page();external=[]
 c.on('request',lambda r:external.append(r.url) if not r.url.startswith(origin+'/') and not r.url.startswith(('blob:','data:')) else None)
 def ready(pg):expect(pg.locator('#lt-app-shell')).to_be_visible(timeout=20000);assert pg.evaluate('!!window.MiBowlingLTHost')
 page.goto(origin+'/',wait_until='commit');ready(page)
 # Seed only synthetic state using the host contract. Then reopen with a normal document.
 page.evaluate("""() => {const v={version:2,hand:'zurdo',balls:[{id:'LAB-B',brand:'Ficticia',model:'Propia',photo:'data:image/png;base64,FAKE'}],patterns:[{id:'LAB-PDF',name:'Patrón ficticio',pdfName:'ficticio.pdf'}],sessions:[]};localStorage.setItem('mi-bowling-analitica-v2',JSON.stringify(v));localStorage.setItem('mi-bowling-ball-selection-v1','{\"__next__\":[\"LAB-B\"]}');}""")
 page.evaluate("""() => new Promise((res,rej)=>{const r=indexedDB.open('mi-bowling-patrones-pdf',1);r.onupgradeneeded=()=>r.result.createObjectStore('pdf');r.onerror=()=>rej(r.error);r.onsuccess=()=>{const d=r.result,t=d.transaction('pdf','readwrite');t.objectStore('pdf').put(new Blob(['%PDF-1.4\\nFICTICIO\\n%%EOF'],{type:'application/pdf'}),'LAB-PDF');t.oncomplete=()=>{d.close();res()};t.onerror=()=>rej(t.error);};})""")
 page.reload(wait_until='commit');ready(page);before=page.evaluate('window.MiBowlingBackup.snapshot()')
 second=c.new_page();second.goto(origin+'/',wait_until='commit');expect(second.locator('#lt-gate-status')).to_contain_text('Otra ventana');assert not second.evaluate('!!window.MiBowlingLTHost')
 page.evaluate("go('ajustes')");page.locator('#lt-open').click();page.locator('#lt-file').set_input_files(str(root/'evidence/fixture.sqlite'));expect(page.locator('#lt-choice')).to_be_visible();page.locator('#lt-user').select_option('1');page.locator('[data-event="1"]').select_option('oficial');page.locator('[data-event="2"]').select_option('entrenamiento');page.locator('#lt-preview').click();expect(page.locator('#lt-review')).to_be_visible();page.locator('#lt-incomplete').check();page.locator('#lt-confirm').check();page.locator('#lt-apply').click();expect(page.locator('#lt-status')).to_contain_text('6 partidas añadidas',timeout=20000)
 with page.expect_download() as dl:page.locator('#lt-backup').click()
 backup=json.loads(pathlib.Path(dl.value.path()).read_text());assert backup['storage']==before['storage'];assert backup['pdfs']==before['pdfs'];page.locator('#lt-close').click();after=page.evaluate('window.MiBowlingBackup.snapshot()');assert after['pdfs']==before['pdfs'];assert all(v==after['storage'][k] for k,v in before['storage'].items() if k!=key);assert page.evaluate("aggregate('oficial').totals.join(',')")=='300,150,90';assert page.evaluate("aggregate('entrenamiento').games.length")==2
 page.close();second.reload(wait_until='commit');ready(second);assert second.evaluate("aggregate('oficial').totals.join(',')")=='300,150,90';assert second.evaluate('window.MiBowlingLTGate.journal.get()')['status']=='applied';assert second.evaluate('window.MiBowlingBackup.snapshot()')['pdfs']==before['pdfs']
 second.evaluate("go('ajustes')");second.locator('#lt-open').click();second.locator('#lt-file').set_input_files(str(root/'evidence/fixture.sqlite'));expect(second.locator('#lt-choice')).to_be_visible();second.locator('#lt-user').select_option('1');second.locator('[data-event="1"]').select_option('oficial');second.locator('[data-event="2"]').select_option('entrenamiento');second.locator('#lt-preview').click();expect(second.locator('#lt-summary')).to_contain_text('6 duplicadas');second.locator('#lt-close').click()
 # Real worker activation + cache offline, no forced activation or clearing old caches.
 second.evaluate('navigator.serviceWorker.ready.then(()=>true)');second.reload(wait_until='commit');ready(second);second.wait_for_function('!!navigator.serviceWorker.controller');c.set_offline(True);second.reload(wait_until='commit');ready(second);assert second.evaluate("aggregate('oficial').games.length")==3;assert not external, external
 b.close();print(f'PASS {a.engine}: real writer, SQLite worker, backup IDB, reload, duplicates and offline')
