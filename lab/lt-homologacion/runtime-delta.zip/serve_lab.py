#!/usr/bin/env python3
"""Only loopback private synthetic LAB; does not serve any parent/user database."""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote,urlsplit
import json, re
ROOT=Path(__file__).resolve().parent/'app'
MANIFEST=json.loads((ROOT.parent/'evidence/cache-manifest.json').read_text())
ALLOWED={u.split('?')[0].rstrip('/') for u in MANIFEST}|{'sw.js'}
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(ROOT),**kw)
 def do_GET(self):
  path=unquote(urlsplit(self.path).path).lstrip('/').rstrip('/')
  if path not in ALLOWED or '..' in path.split('/') or '\\' in path or self.headers.get('Host')!='127.0.0.1:8767':self.send_error(404);return
  super().do_GET()
 def do_HEAD(self):self.send_error(405)
 def list_directory(self,path):self.send_error(404);return None
 def end_headers(self):
  self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer');self.send_header('X-Frame-Options','DENY')
  self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline' blob:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; worker-src 'self' blob:; frame-src blob:; object-src 'none'; base-uri 'self'; form-action 'none'")
  super().end_headers()
 extensions_map={**SimpleHTTPRequestHandler.extensions_map,'.mjs':'text/javascript','.js':'text/javascript'}
if __name__=='__main__':ThreadingHTTPServer(('127.0.0.1',8767),Handler).serve_forever()
